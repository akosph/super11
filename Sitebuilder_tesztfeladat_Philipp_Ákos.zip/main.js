 /*Box 1 Active button coloring jQuery*/
 $('.Box1Button').on('click', function(){
      $('.Box1Button').removeClass('selected');
      $(this).addClass('selected');
  });


 /*Radio  button coloring (active) jQuery*/
  $('.Box1RadioButton').on('click', function(){
      $('.Box1RadioButton').removeClass('selected');
      $(this).addClass('selected');
  });